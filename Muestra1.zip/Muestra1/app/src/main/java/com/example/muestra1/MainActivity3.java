package com.example.muestra1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.muestra1.databinding.ActivityMain3Binding;

public class MainActivity3 extends AppCompatActivity {

    DatabaseHelper databaseHelper;
    ActivityMain3Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMain3Binding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());

        databaseHelper = new DatabaseHelper(this);

        binding.btRegistrate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usuario = binding.etUsuario.getText().toString();
                String password = binding.etPassword.getText().toString();
                String nombre_y_apellidos = binding.etNombresyApellidos.getText().toString();
                String dpi = binding.etDPI.getText().toString();
                String telefono = binding.etFon.getText().toString();
                String direccion = binding.etDomicilio.getText().toString();
                String correo = binding.etCorreo.getText().toString();

                if (usuario.equals("") || password.equals("") || nombre_y_apellidos.equals("") || dpi.equals("") || telefono.equals("") || direccion.equals("") || correo.equals(""))
                    Toast.makeText(MainActivity3.this, "Se deben llenar todos los campos...", Toast.LENGTH_SHORT).show();
                else{
                    Boolean checkUser = databaseHelper.checkUsuario();
                    if(checkUser == false){
                        Boolean insert = databaseHelper.insertData(usuario, password, nombre_y_apellidos, dpi, telefono, direccion, correo);

                    if (insert == true){
                        Toast.makeText(MainActivity3.this, "Registrado correctamente!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(MainActivity3.this, "Registro fallido...", Toast.LENGTH_SHORT).show();
                    }
                    }else{
                        Toast.makeText(MainActivity3.this, "Usuario ya existe", Toast.LENGTH_SHORT).show();
                    }
                } else{
                    Toast.makeText(MainActivity3.this, "Usuario no válido", Toast.LENGTH_SHORT).show();
                }
            }
        });

        binding.

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}