package com.example.muestra1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String databaseName = "Signup.db";

    public DatabaseHelper(@Nullable Context context) {
        super(context, "Signup.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDatabase) {
        MyDatabase.execSQL("create Table allusers(usuario TEXT primary key, password TEXT, nombre_y_apellidos TEXT, dpi TEXT, telefono TEXT, direccion TEXT, correo TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDatabase, int i, int i1) {
        MyDatabase.execSQL("drop table if exists allusers");
    }

    public Boolean insertData(String usuario, String password, String nombre_y_apellidos, String dpi, String telefono, String direccion, String correo) {
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("usuario",usuario);
        contentValues.put("password",password);
        contentValues.put("nombre_y_apellidos",nombre_y_apellidos);
        contentValues.put("dpi",dpi);
        contentValues.put("telefono",telefono);
        contentValues.put("direccion",direccion);
        contentValues.put("correo",correo);
        long result = MyDatabase.insert("allusers",null, contentValues);

        if (result == -1){
            return false;
        }else{
            return true;
        }
    }

    public Boolean checkUsuario(String usuario){
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        Cursor cursor = MyDatabase.rawQuery("Select * from allusers where usuario = ?", new String[]{usuario});

        if (cursor.getCount() > 0){
            return true;
        } else{
            return false;
        }
    }

    public Boolean checkUserPassword(String usuario, String password){
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        Cursor cursor = MyDatabase.rawQuery("Select * from allusers where usuario = ? and password = ?", new String[]{usuario, password});

        if (cursor.getCount() > 0){
            return true;
        } else{
            return false;
        }
    }
}
