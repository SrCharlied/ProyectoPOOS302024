package com.example.muestra1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.muestra1.databinding.ActivityMain6Binding;
import com.example.muestra1.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ListView lvTrabajadores;

    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());

        lvTrabajadores = findViewById(R.id.lvTrabajadores);
        List<Proovedor> listaProveedores = new ArrayList<>();
        listaProveedores.add(new Proovedor("Juan Ovando", "0000 00000 0000", "Plomeria", "Reparacion de fugas",
                "Zona 1, Ciudad de Guatemala", 123456789));
        listaProveedores.add(new Proovedor("Mariana Orozco", "1111 22222 3333", "Plomeria", "Reparacion de fugas",
                "Zona 13, Ciudad de Guatemala", 28385859));

        ProveedorAdapter adapter = new ProveedorAdapter(this, listaProveedores);
        lvTrabajadores.setAdapter(adapter);

        lvTrabajadores.setOnItemClickListener((parent, view, position, id) -> {
            Proovedor proveedorSeleccionado = (Proovedor) parent.getItemAtPosition(position);

            Intent intent = new Intent(MainActivity.this, MainActivity6.class);

            intent.putExtra("nombre", proveedorSeleccionado.getNombre());
            intent.putExtra("telefono", proveedorSeleccionado.getTelefono());

            startActivity(intent);
        });


        binding.btRegresarCat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity5.class);
                startActivity(intent);
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}