package com.example.muestra1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class ProveedorAdapter extends ArrayAdapter<Proovedor> {

    public ProveedorAdapter(Context context, List<Proovedor> proveedores) {
        super(context, 0, proveedores);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Inflar el layout si no se ha hecho
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_proveedor, parent, false);
        }

        // Obtener el objeto `Proveedor` actual
        Proovedor proveedor = getItem(position);

        // Encontrar y asignar los elementos de la vista
        TextView tvNombre = convertView.findViewById(R.id.tvNombre);
        TextView tvTelefono = convertView.findViewById(R.id.tvTelefono);

        // Asignar los datos de `Proveedor` a los elementos de la vista
        if (proveedor != null) {
            tvNombre.setText(proveedor.getNombre());
            tvTelefono.setText(proveedor.getTelefono());
        }

        return convertView;
    }
}
