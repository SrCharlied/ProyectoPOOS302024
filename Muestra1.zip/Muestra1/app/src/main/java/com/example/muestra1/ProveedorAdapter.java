package com.example.muestra1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class ProveedorAdapter extends ArrayAdapter<Proovedor> {

    public ProveedorAdapter(Context context, List<Proovedor> proveedores) {
        super(context, 0, proveedores);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_proveedor, parent, false);
        }

        Proovedor proveedor = getItem(position);

        TextView tvNombre = convertView.findViewById(R.id.tvNombre);
        TextView tvTelefono = convertView.findViewById(R.id.tvTelefono);
        

        if (proveedor != null) {
            tvNombre.setText(proveedor.getNombre());
            tvTelefono.setText(String.valueOf(proveedor.getTelefono()));
        }

        return convertView;
    }
}
