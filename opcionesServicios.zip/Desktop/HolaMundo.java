public class HolaMundo{
	public static void main (String[] args)
	{
		System.out.println("hola mundo");
		int resultado = 9/3;
		System.out.println("El texto luego de la división");
	}
}